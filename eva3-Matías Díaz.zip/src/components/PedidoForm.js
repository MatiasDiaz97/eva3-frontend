
import React, { useState, useEffect } from "react";

const PedidoForm = () => {
  const [productos, setProductos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    prefijo: "+569",
    telefono: "",
    cantidad: 1,
    material: "",
    urgente: false,
    fecha: new Date().toISOString().split("T")[0],
  });

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then(res => res.json())
      .then(data => {
        setProductos(data.map(p => p.title));
        setLoading(false);
      })
      .catch(() => {
        setProductos([]);
        setLoading(false);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    // Validación para campo numérico (solo 8 dígitos)
    if (name === "telefono") {
      const numericValue = value.replace(/[^0-9]/g, "").slice(0, 8);
      setFormData(prev => ({ ...prev, [name]: numericValue }));
      return;
    }

    setFormData(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const pedidosPrevios = JSON.parse(localStorage.getItem("pedidos") || "[]");
    const nuevos = [...pedidosPrevios, formData];
    localStorage.setItem("pedidos", JSON.stringify(nuevos));
    alert("Pedido guardado correctamente");
    setFormData({
      nombre: "",
      email: "",
      prefijo: "+569",
      telefono: "",
      cantidad: 1,
      material: "",
      urgente: false,
      fecha: new Date().toISOString().split("T")[0],
    });
  };

  return (
    <section>
      <h2>Formulario de Pedido</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Nombre:
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
            placeholder="Ej: Juan Pérez"
            required
          />
        </label><br/>

        <label>
          Email:
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Ej: correo@ejemplo.com"
            required
          />
        </label><br/>

        <label>
          Teléfono:
          <div style={{ display: "flex", gap: "10px" }}>
            <select name="prefijo" value={formData.prefijo} onChange={handleChange}>
              <option value="+569">+569</option>
              <option value="+562">+562</option>
            </select>
            <input
              type="text"
              name="telefono"
              value={formData.telefono}
              onChange={handleChange}
              placeholder="Ej: 12345678"
              inputMode="numeric"
              maxLength={8}
              required
            />
          </div>
        </label><br/>

        <label>
          Cantidad:
          <input
            type="number"
            name="cantidad"
            value={formData.cantidad}
            onChange={handleChange}
            min="1"
          />
        </label><br/>

        <label>
          Material:
          {loading ? (
            <p>Cargando materiales...</p>
          ) : (
            <select name="material" value={formData.material} onChange={handleChange} required>
              <option value="">Seleccione</option>
              {productos.map((p, i) => (
                <option key={i} value={p}>{p}</option>
              ))}
            </select>
          )}
        </label><br/>

        <label>
          Pedido urgente:
          <input
            type="checkbox"
            name="urgente"
            checked={formData.urgente}
            onChange={handleChange}
          />
        </label><br/>

        <label>
          Fecha:
          <input
            type="date"
            name="fecha"
            value={formData.fecha}
            onChange={handleChange}
          />
        </label><br/>

        <button type="submit">Enviar Pedido</button>
      </form>
    </section>
  );
};

export default PedidoForm;
