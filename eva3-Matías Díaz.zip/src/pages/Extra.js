
import React from "react";

const Extra = () => (
  <section>
    <h2>Promociones Especiales</h2>
    <p>Aprovecha nuestras ofertas por temporada en herramientas eléctricas y materiales de construcción.</p>
    <ol>
      <li>Combo Martillo + Clavos</li>
      <li>Cemento a precio rebajado</li>
      <li>10% de descuento en compras mayores a $50.000</li>
    </ol>
  </section>
);

export default Extra;
