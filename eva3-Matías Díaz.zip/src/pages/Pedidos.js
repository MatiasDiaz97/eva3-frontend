
import React, { useEffect, useState } from "react";
import "../eva2_styles.css";

const Pedidos = () => {
  const [registros, setRegistros] = useState([]);
  const [editIndex, setEditIndex] = useState(null);
  const [editData, setEditData] = useState({});

  useEffect(() => {
    const saved = localStorage.getItem("pedidos");
    if (saved) {
      setRegistros(JSON.parse(saved));
    }
  }, []);

  const eliminar = (index) => {
    const nuevos = registros.filter((_, i) => i !== index);
    setRegistros(nuevos);
    localStorage.setItem("pedidos", JSON.stringify(nuevos));
  };

  const iniciarEdicion = (index) => {
    setEditIndex(index);
    setEditData(registros[index]);
  };

  const cancelarEdicion = () => {
    setEditIndex(null);
    setEditData({});
  };

  const guardarCambios = () => {
    const actualizados = [...registros];
    actualizados[editIndex] = editData;
    setRegistros(actualizados);
    localStorage.setItem("pedidos", JSON.stringify(actualizados));
    cancelarEdicion();
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setEditData(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  return (
    <section>
      <h2 style={{ marginBottom: "20px" }}>Pedidos Realizados</h2>
      {registros.length === 0 ? (
        <p>No hay pedidos registrados aún.</p>
      ) : (
        <ul style={{ listStyleType: "none", padding: 0 }}>
          {registros.map((reg, i) => (
            <li key={i} style={{
              backgroundColor: "#eaf2f8",
              border: "1px solid #ccc",
              borderRadius: "12px",
              padding: "15px",
              marginBottom: "15px",
              boxShadow: "0 2px 5px rgba(0, 0, 0, 0.1)"
            }}>
              {editIndex === i ? (
                <>
                  <ul style={{ paddingLeft: "20px" }}>
                    <li><strong>Nombre:</strong> <input name="nombre" value={editData.nombre} onChange={handleChange} /></li>
                    <li><strong>Email:</strong> <input name="email" value={editData.email} onChange={handleChange} /></li>
                    <li><strong>Material:</strong> <input name="material" value={editData.material} onChange={handleChange} /></li>
                    <li><strong>Cantidad:</strong> <input name="cantidad" type="number" value={editData.cantidad} onChange={handleChange} /></li>
                    <li><strong>Urgente:</strong> <input name="urgente" type="checkbox" checked={editData.urgente} onChange={handleChange} /></li>
                    <li><strong>Fecha:</strong> <input name="fecha" type="date" value={editData.fecha} onChange={handleChange} /></li>
                  </ul>
                  <div style={{ marginTop: "10px" }}>
                    <button onClick={guardarCambios}>Guardar</button>
                    <button onClick={cancelarEdicion} style={{ marginLeft: "10px" }}>Cancelar</button>
                  </div>
                </>
              ) : (
                <>
                  <ul style={{ paddingLeft: "20px" }}>
                    <li><strong>Nombre:</strong> {reg.nombre}</li>
                    <li><strong>Email:</strong> {reg.email}</li>
                    <li><strong>Material:</strong> {reg.material}</li>
                    <li><strong>Cantidad:</strong> {reg.cantidad}</li>
                    <li><strong>Urgente:</strong> {reg.urgente ? "Sí" : "No"}</li>
                    <li><strong>Fecha:</strong> {reg.fecha}</li>
                  </ul>
                  <div style={{ marginTop: "10px" }}>
                    <button onClick={() => iniciarEdicion(i)}>Editar</button>
                    <button onClick={() => eliminar(i)} style={{ marginLeft: "10px" }}>Eliminar</button>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
    </section>
  );
};

export default Pedidos;
