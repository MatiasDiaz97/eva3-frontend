
import React from "react";

const Contact = () => (
  <section>
    <h2>Contáctanos</h2>
    <p>📞 Teléfono: +56 9 1234 5678</p>
    <p>📧 Email: contacto@ferreteria-teresa.cl</p>
    <p>📍 Dirección: Av. Recoleta 1234, Santiago, Chile</p>
  </section>
);

export default Contact;
