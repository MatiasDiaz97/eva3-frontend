
import React from "react";
import bodegaImg from "../assets/Bodega.webp";

const Home = () => (
  <section>
    <h2>Bienvenidos a Ferretería Teresa</h2>
    <p>Tu ferretería de confianza con los mejores materiales y atención personalizada.</p>
    <img src={bodegaImg} alt="Bodega" style={{ maxWidth: "100%", borderRadius: "10px" }} />
  </section>
);

export default Home;
