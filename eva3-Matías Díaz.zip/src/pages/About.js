
import React from "react";

const About = () => (
  <section>
    <h2>¿Quiénes Somos?</h2>
    <p>Ferretería Teresa nace para brindar soluciones rápidas y eficientes en construcción y mejoramiento del hogar.</p>
    <ul>
      <li>Más de 20 años de experiencia</li>
      <li>Productos nacionales e importados</li>
      <li>Atención personalizada</li>
    </ul>
  </section>
);

export default About;
