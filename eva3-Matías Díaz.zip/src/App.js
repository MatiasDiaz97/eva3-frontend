
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Extra from "./pages/Extra";
import Pedidos from "./pages/Pedidos";
import PedidoForm from "./components/PedidoForm";
import "./eva2_styles.css";

function App() {
  return (
    <Router>
      <header>
        <img src={require("./assets/Logo.jpg")} alt="Logo" className="logo" />
        <h1>Gestión de Pedidos de Bodega</h1>
        <p>Ferretería Teresa</p>
      </header>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/about">Quienes Somos</Link>
        <Link to="/contact">Contacto</Link>
        <Link to="/extra">Otra</Link>
        <Link to="/formulario">Nuevo Pedido</Link>
        <Link to="/pedidos">Pedidos Realizados</Link>
      </nav>
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/extra" element={<Extra />} />
          <Route path="/formulario" element={<PedidoForm />} />
          <Route path="/pedidos" element={<Pedidos />} />
        </Routes>
      </main>
    </Router>
  );
}

export default App;
